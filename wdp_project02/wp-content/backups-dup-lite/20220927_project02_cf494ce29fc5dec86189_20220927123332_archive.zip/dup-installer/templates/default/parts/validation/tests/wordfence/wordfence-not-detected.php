<?php

/**
 *
 * @package templates/default
 *
 */

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<div class="sub-title">STATUS</div>
<p class="green"> Having Wordfence in a parent site can interfere with the install, however no such condition was detected. </p>